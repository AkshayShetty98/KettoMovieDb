// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';

import 'package:kettomoviedb/core/usecase/usecase.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_intro_entity.dart';
import 'package:kettomoviedb/features/movies/domain/repositories/movie_repository.dart';

@lazySingleton
class GetUpcomingdMovies
    extends UseCase<AllMoviesIntroEntity, GetUpcomingMoviesParams> {
  final MovieRepository movieRepository;

  GetUpcomingdMovies({
    required this.movieRepository,
  });

  @override
  Future<Either<Exception, AllMoviesIntroEntity>> call(
      GetUpcomingMoviesParams params) async {
    return await movieRepository.getUpcomingMovies(params.page);
  }
}

class GetUpcomingMoviesParams extends Equatable {
  final int page;

  const GetUpcomingMoviesParams({required this.page});

  @override
  List<Object> get props => [page];
}
