import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';
import 'package:kettomoviedb/core/usecase/usecase.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_trailer_entity.dart';
import 'package:kettomoviedb/features/movies/domain/repositories/movie_repository.dart';

@lazySingleton
class GetMovieTrailer
    extends UseCase<MovieTrailerEntity, GetMovieTrailerParams> {
  final MovieRepository movieRepository;

  GetMovieTrailer({
    required this.movieRepository,
  });

  @override
  Future<Either<Exception, MovieTrailerEntity>> call(
      GetMovieTrailerParams params) async {
    return await movieRepository.getMovieTrailerUrl(params.movieId);
  }
}

class GetMovieTrailerParams extends Equatable {
  final int movieId;

  const GetMovieTrailerParams({required this.movieId});

  @override
  List<Object> get props => [movieId];
}
