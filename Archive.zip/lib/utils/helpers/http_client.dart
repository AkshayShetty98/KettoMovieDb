import 'dart:convert';
import 'package:http/http.dart';
import 'package:injectable/injectable.dart';
import 'package:kettomoviedb/core/errors/exceptions.dart';
import 'package:kettomoviedb/utils/access-config/app_urls.dart';

@injectable
class HttpClient {
  final Client client = Client();
  String host = baseUrl;

  // factory HttpClient.setAPIhost() => HttpClient(host: baseUrl);

  Uri _getParsedUrl(String path) {
    return Uri.parse('$host$path');
  }

  Map<String, String> _getContentTypeHeader() =>
      {'Content-Type': 'application/json'};

  // Map<String, String> _getContentTypeHeaderFormData() =>
  //     {'Content-Type': 'multipart/form-data'};

  Map<String, String> _generateAuthorizationHeader(
    String token,
  ) =>
      {
        'Authorization':
            'Bearer ${'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJmNTNjNDNlODU4YWRlM2U2NjU4YWJkNjJlZjBhY2ZkZiIsIm5iZiI6MTcyMjE1NTE2OC44NTY1NjUsInN1YiI6IjVlYTNmMjE1ZWM0NTUyMDAyMTNmMjcyYiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.gX_9LkxjRj8h1JVvVFBJW5b0crUxN6XzZLFIO0F8ptE'}',
      };

  Map<String, String> _generateRequestHeaderWithAuthorization(
    String token, [
    Map<String, String> overrideHeader = const {},
  ]) =>
      {
        ..._generateAuthorizationHeader(token),
        ..._getContentTypeHeader(),
        ...overrideHeader,
      };

  Map<String, String> _generateRequestHeaderWithoutAuthorization([
    Map<String, String> overrideHeader = const {},
  ]) =>
      {
        ..._getContentTypeHeader(),
        ...overrideHeader,
      };

  // Map<String, String> _generateRequestHeaderWithoutAuthorizationFormData([
  //   Map<String, String> overrideHeader = const {},
  // ]) =>
  //     {
  //       ..._getContentTypeHeaderFormData(),
  //       ...overrideHeader,
  //     };

  // Map<String, String> _generateRequestHeaderWithAuthorizationFormData(
  //   String token, [
  //   Map<String, String> overrideHeader = const {},
  // ]) =>
  //     {
  //       ..._generateAuthorizationHeader(
  //         token,
  //       ),
  //       ..._getContentTypeHeaderFormData(),
  //       ...overrideHeader,
  //     };

  dynamic get(
      {required String path, bool withAuthorizationHeader = true}) async {
    final requestHeader = withAuthorizationHeader
        ? _generateRequestHeaderWithAuthorization('')
        : _generateRequestHeaderWithoutAuthorization();

    final Response response = await client
        .get(
          _getParsedUrl(path),
          headers: requestHeader,
        )
        .timeout(const Duration(seconds: 10));

    return getResponse(response, '');
  }

  dynamic post({required String path, dynamic body, dynamic token}) async {
    final requestHeader = token != null && token.isNotEmpty
        ? _generateRequestHeaderWithAuthorization(token)
        : _generateRequestHeaderWithoutAuthorization();

    final Response response = await client
        .post(
          _getParsedUrl(path),
          body: encodeRequestBody(body, requestHeader['Content-Type']!),
          headers: requestHeader,
        )
        .timeout(const Duration(seconds: 25));

    return getResponse(response, body);
  }

  // dynamic multipartPost(
  //     {required String path,
  //     required Map<String, dynamic> formData,
  //     dynamic token}) async {
  //   final requestHeader = token != null && token.isNotEmpty
  //       ? _generateRequestHeaderWithAuthorizationFormData(
  //           token, await getUserId)
  //       : _generateRequestHeaderWithoutAuthorizationFormData();

  //   MultipartRequest request = MultipartRequest('POST', _getParsedUrl(path));
  //   request.headers.addAll(requestHeader);
  //   formData.forEach((key, value) async {
  //     if (value is File) {
  //       request.files.add(await MultipartFile.fromPath(key, value.path));
  //     }
  //   });
  //   formData.removeWhere((key, value) => value is File);
  //   try {
  //     Map<String, dynamic> fieldsData = Map.from(formData);

  //     fieldsData.forEach((key, value) {
  //       request.fields[key] = value.toString();
  //     });

  //     //request.fields.addAll(fieldsData);
  //   } catch (e) {
  //     debugPrint(e.toString());
  //   }

  //   final Response response = await Response.fromStream(await request.send())
  //       .timeout(const Duration(seconds: 25));

  //   return getResponse(response, formData);
  // }

  dynamic encodeRequestBody(dynamic data, String contentType) {
    return contentType == 'application/json'
        ? utf8.encode(json.encode(data))
        : data;
  }

  dynamic getResponse(Response response, dynamic reqBody) {
    switch (response.statusCode) {
      case 200:
      case 201:
        final responseJson = json.decode(response.body);
        return responseJson;
      // case 204:
      //   return null;
      case 400:
        throw BadRequestException();
      case 401:
        throw UnauthorizedException();
      case 403:
        throw ForbiddenException();
      case 404:
        throw CustomException();

      case 500:
        throw ServerException();
      case 503:
        throw DowntimeException();
      default:
        throw UnknownException();
    }
  }

  void sendIssueToSentry(
      Exception e, Response response, dynamic requestObject) async {
    // Map<String, dynamic> sentryLog = {
    //   'exceptionType': e.toString(),
    //   'exceptionStatusCode': response.statusCode.toString(),
    //   'requestObject': requestObject,
    //   'responseObject': json.decode(response.body)
    // };

    // await Sentry.captureException(e);
  }
}
