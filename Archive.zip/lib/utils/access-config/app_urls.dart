String get baseUrl {
  return 'https://api.themoviedb.org/3/';
}

String get imgBaseUrl {
  return 'https://image.tmdb.org/t/p/original';
}

class AppUrls {
  static const String GET_POPULARMOVIES_URL = 'movie/popular';
  static const String GET_TOPMOVIES_URL = 'movie/top_rated';
  static const String GET_UPCOMINGMOVIES_URL = 'movie/upcoming';
  static const String GET_MOVIEDETAIL_URL = 'movie';
  static const String GET_MOVIETRAILER_URL = 'movie';
}
