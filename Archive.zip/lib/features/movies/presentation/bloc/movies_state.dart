// ignore_for_file: public_member_api_docs, sort_constructors_first
part of 'movies_bloc.dart';

abstract class MoviesState extends Equatable {
  const MoviesState();

  @override
  List<Object> get props => [];
}

class MoviesInitial extends MoviesState {}

class GetPopularMoviesLoading extends MoviesState {}

class GetPopularMoviesSuccess extends MoviesState {
  final AllMoviesIntroEntity allMoviesIntroEntity;
  const GetPopularMoviesSuccess({
    required this.allMoviesIntroEntity,
  });
  @override
  List<Object> get props => [allMoviesIntroEntity];
}

class GetPopularMoviesFailure extends MoviesState {}

class GetTopratedMoviesLoading extends MoviesState {}

class GetTopratedMoviesSuccess extends MoviesState {
  final AllMoviesIntroEntity allMoviesIntroEntity;
  const GetTopratedMoviesSuccess({
    required this.allMoviesIntroEntity,
  });
  @override
  List<Object> get props => [allMoviesIntroEntity];
}

class GetTopratedMoviesFailure extends MoviesState {}

class GetUpcomingMoviesLoading extends MoviesState {}

class GetUpcomingMoviesSuccess extends MoviesState {
  final AllMoviesIntroEntity allMoviesIntroEntity;
  const GetUpcomingMoviesSuccess({
    required this.allMoviesIntroEntity,
  });
  @override
  List<Object> get props => [allMoviesIntroEntity];
}

class GetUpcomingMoviesFailure extends MoviesState {}

class GetMovieDetailLoading extends MoviesState {}

class GetMovieDetailSuccess extends MoviesState {
  final MovieDetailEntity movieDetailEntity;
  const GetMovieDetailSuccess({
    required this.movieDetailEntity,
  });
  @override
  List<Object> get props => [movieDetailEntity];
}

class GetMovieDetailFailure extends MoviesState {}

class GetMovieTrailerLoading extends MoviesState {}

class GetMovieTrailerSuccess extends MoviesState {
  final MovieTrailerEntity movieTrailerEntity;
  const GetMovieTrailerSuccess({
    required this.movieTrailerEntity,
  });
  @override
  List<Object> get props => [movieTrailerEntity];
}

class GetMovieTrailerFailure extends MoviesState {}

class GetMovieCastLoading extends MoviesState {}

class GetMovieCastSuccess extends MoviesState {
  final List<MovieCastEntity> movieCastEntity;
  const GetMovieCastSuccess({
    required this.movieCastEntity,
  });
  @override
  List<Object> get props => [movieCastEntity];
}

class GetMovieCastFailure extends MoviesState {}
