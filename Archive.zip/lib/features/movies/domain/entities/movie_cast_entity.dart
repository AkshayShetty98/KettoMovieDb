// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:equatable/equatable.dart';

class MovieCastEntity extends Equatable {
  final String castName;
  final String castPicUrl;
  const MovieCastEntity({
    required this.castName,
    required this.castPicUrl,
  });

  @override
  List<Object> get props => [castName, castPicUrl];
}
