import 'package:injectable/injectable.dart';
import 'package:kettomoviedb/core/injection/di_injectable.dart';
import 'package:kettomoviedb/features/movies/data/models/get_movie_cast_model.dart';
import 'package:kettomoviedb/features/movies/data/models/get_movie_detail_model.dart';
import 'package:kettomoviedb/features/movies/data/models/get_movie_trailer_model.dart';
import 'package:kettomoviedb/features/movies/data/models/get_popular_movies_model.dart';
import 'package:kettomoviedb/features/movies/data/models/get_toprated_movies_model.dart';
import 'package:kettomoviedb/features/movies/data/models/get_upcoming_movies_model.dart';
import 'package:kettomoviedb/utils/access-config/app_urls.dart';
import 'package:kettomoviedb/utils/helpers/http_client.dart';

abstract class MovieRemoteDataSource {
  Future<GetPopularMoviesModel> getPopularMovies(int page);
  Future<GetTopratedMoviesModel> getTopRatedMovies(int page);
  Future<GetUpcomingMoviesModel> getUpcomingMovies(int page);
  Future<GetMovieDetailModel> getMovieDetail(int movieId);
  Future<GetMovieTrailerModel> getMovieTrailer(int movieId);
  Future<GetMovieCastModel> getMovieCast(int movieId);
}

@LazySingleton(as: MovieRemoteDataSource)
class MovieRemoteDataSourceImpl implements MovieRemoteDataSource {
  HttpClient httpClient;

  MovieRemoteDataSourceImpl(this.httpClient);

  @override
  Future<GetPopularMoviesModel> getPopularMovies(int page) async {
    httpClient = sl<HttpClient>();
    String typeUrl = AppUrls.GET_POPULARMOVIES_URL;
    String path = '$typeUrl?language=en-US&page=$page';

    final resultJson = await httpClient.get(path: path);
    GetPopularMoviesModel getPopularMoviesModel =
        GetPopularMoviesModel.fromJson(resultJson);

    return getPopularMoviesModel;
  }

  @override
  Future<GetTopratedMoviesModel> getTopRatedMovies(int page) async {
    httpClient = sl<HttpClient>();
    String typeUrl = AppUrls.GET_TOPMOVIES_URL;
    String path = '$typeUrl?language=en-US&page=$page';

    final resultJson = await httpClient.get(path: path);
    GetTopratedMoviesModel getTopratedMoviesModel =
        GetTopratedMoviesModel.fromJson(resultJson);

    return getTopratedMoviesModel;
  }

  @override
  Future<GetUpcomingMoviesModel> getUpcomingMovies(int page) async {
    httpClient = sl<HttpClient>();
    String typeUrl = AppUrls.GET_UPCOMINGMOVIES_URL;
    String path = '$typeUrl?language=en-US&page=$page';

    final resultJson = await httpClient.get(path: path);
    GetUpcomingMoviesModel getUpcomingMoviesModel =
        GetUpcomingMoviesModel.fromJson(resultJson);

    return getUpcomingMoviesModel;
  }

  @override
  Future<GetMovieDetailModel> getMovieDetail(int movieId) async {
    httpClient = sl<HttpClient>();
    String typeUrl = AppUrls.GET_MOVIEDETAIL_URL;
    String path = '$typeUrl/$movieId';

    final resultJson = await httpClient.get(path: path);
    GetMovieDetailModel getMovieDetailModel =
        GetMovieDetailModel.fromJson(resultJson);

    return getMovieDetailModel;
  }

  @override
  Future<GetMovieTrailerModel> getMovieTrailer(int movieId) async {
    httpClient = sl<HttpClient>();
    String typeUrl = AppUrls.GET_MOVIETRAILER_URL;
    String path = '$typeUrl/$movieId/videos';

    final resultJson = await httpClient.get(path: path);
    GetMovieTrailerModel getMovieTrailerModel =
        GetMovieTrailerModel.fromJson(resultJson);

    return getMovieTrailerModel;
  }

  @override
  Future<GetMovieCastModel> getMovieCast(int movieId) async {
    httpClient = sl<HttpClient>();
    String typeUrl = AppUrls.GET_MOVIETRAILER_URL;
    String path = '$typeUrl/$movieId/credits';

    final resultJson = await httpClient.get(path: path);
    GetMovieCastModel getMovieCastModel =
        GetMovieCastModel.fromJson(resultJson);

    return getMovieCastModel;
  }
}
