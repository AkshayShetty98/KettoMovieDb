import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

TextStyle bodySmallStyle(BuildContext context) => const TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.w400,
      fontFamily: 'JosefinSans',
      fontSize: 15,
      height: 1.4,
    );
TextStyle bodyMediumStyle(BuildContext context) => const TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.w400,
      fontFamily: 'JosefinSans',
      fontSize: 18,
      height: 1.4,
    );

TextStyle bodyLargeStyle() => const TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.w400,
      fontFamily: 'JosefinSans',
      fontSize: 22,
      height: 1.4,
    );

TextStyle headlineSmallStyle(BuildContext context) => const TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.w600,
      fontFamily: 'JosefinSans',
      fontSize: 17,
      height: 1.4,
    );
TextStyle headlineMediumStyle(BuildContext context) => const TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.w600,
      fontFamily: 'JosefinSans',
      fontSize: 20,
      height: 1.4,
    );
TextStyle headlineLargeStyle(BuildContext context) => const TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.w600,
      fontFamily: 'JosefinSans',
      fontSize: 35,
      height: 1.4,
    );
