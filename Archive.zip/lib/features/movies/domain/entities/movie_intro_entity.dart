// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:equatable/equatable.dart';

class AllMoviesIntroEntity extends Equatable {
  final List<MovieIntroEntity> allMovies;
  final int currentPageIndex;
  final int totalPages;
  final int totalMovies;
  const AllMoviesIntroEntity({
    required this.allMovies,
    required this.currentPageIndex,
    required this.totalPages,
    required this.totalMovies,
  });

  @override
  List<Object> get props =>
      [allMovies, currentPageIndex, totalPages, totalMovies];
}

class MovieIntroEntity extends Equatable {
  final int movieId;
  final String movieName;
  final String moviePosterUrl;
  const MovieIntroEntity({
    required this.movieId,
    required this.movieName,
    required this.moviePosterUrl,
  });

  @override
  List<Object> get props => [movieId, movieName, moviePosterUrl];
}
