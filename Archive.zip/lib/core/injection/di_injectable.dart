import 'package:get_it/get_it.dart';
import 'package:injectable/injectable.dart';
import 'package:kettomoviedb/core/injection/di_injectable.config.dart';

GetIt sl = GetIt.instance;

@InjectableInit(preferRelativeImports: false)
void configureDependencies() => sl.init();
