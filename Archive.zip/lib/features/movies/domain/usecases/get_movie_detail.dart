import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';
import 'package:kettomoviedb/core/usecase/usecase.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_detail_entity.dart';
import 'package:kettomoviedb/features/movies/domain/repositories/movie_repository.dart';

@lazySingleton
class GetMovieDetail extends UseCase<MovieDetailEntity, GetMovieDetailParams> {
  final MovieRepository movieRepository;

  GetMovieDetail({
    required this.movieRepository,
  });

  @override
  Future<Either<Exception, MovieDetailEntity>> call(
      GetMovieDetailParams params) async {
    return await movieRepository.getMovieDetail(params.movieId);
  }
}

class GetMovieDetailParams extends Equatable {
  final int movieId;

  const GetMovieDetailParams({required this.movieId});

  @override
  List<Object> get props => [movieId];
}
