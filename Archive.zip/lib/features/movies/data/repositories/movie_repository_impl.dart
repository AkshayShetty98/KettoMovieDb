import 'package:dartz/dartz.dart';
import 'package:injectable/injectable.dart';
import 'package:kettomoviedb/core/errors/exceptions.dart';
import 'package:kettomoviedb/features/movies/data/datasources/movie_remote_data_source.dart';
import 'package:kettomoviedb/features/movies/data/models/get_movie_cast_model.dart';
import 'package:kettomoviedb/features/movies/data/models/get_movie_detail_model.dart';
import 'package:kettomoviedb/features/movies/data/models/get_movie_trailer_model.dart';
import 'package:kettomoviedb/features/movies/data/models/get_popular_movies_model.dart';
import 'package:kettomoviedb/features/movies/data/models/get_toprated_movies_model.dart';
import 'package:kettomoviedb/features/movies/data/models/get_upcoming_movies_model.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_cast_entity.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_detail_entity.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_intro_entity.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_trailer_entity.dart';
import 'package:kettomoviedb/features/movies/domain/repositories/movie_repository.dart';

@LazySingleton(as: MovieRepository)
class MovieRepositoryImpl implements MovieRepository {
  final MovieRemoteDataSource movieRemoteDataSource;

  MovieRepositoryImpl(this.movieRemoteDataSource);

  @override
  Future<Either<Exception, AllMoviesIntroEntity>> getPopularMovies(
      int page) async {
    try {
      GetPopularMoviesModel getPopularMoviesModel =
          await movieRemoteDataSource.getPopularMovies(page);
      return Right(getPopularMoviesModel.allPopularMovies());
    } on ServerException {
      return Left(ServerException());
    } on BadRequestException {
      return Left(BadRequestException());
    } on ForbiddenException {
      return Left(ForbiddenException());
    } on UnauthorizedException {
      return Left(UnauthorizedException());
    } on CustomException {
      return Left((CustomException()));
    } on DowntimeException {
      return Left(DowntimeException());
    } catch (e) {
      return Left(UnknownException());
    }
  }

  @override
  Future<Either<Exception, AllMoviesIntroEntity>> getTopRatedMovies(
      int page) async {
    try {
      GetTopratedMoviesModel getTopratedMoviesModel =
          await movieRemoteDataSource.getTopRatedMovies(page);
      return Right(getTopratedMoviesModel.toTopRatedMoviesEntity());
    } on ServerException {
      return Left(ServerException());
    } on BadRequestException {
      return Left(BadRequestException());
    } on ForbiddenException {
      return Left(ForbiddenException());
    } on UnauthorizedException {
      return Left(UnauthorizedException());
    } on CustomException {
      return Left((CustomException()));
    } on DowntimeException {
      return Left(DowntimeException());
    } catch (e) {
      return Left(UnknownException());
    }
  }

  @override
  Future<Either<Exception, AllMoviesIntroEntity>> getUpcomingMovies(
      int page) async {
    try {
      GetUpcomingMoviesModel getUpcomingMoviesModel =
          await movieRemoteDataSource.getUpcomingMovies(page);
      return Right(getUpcomingMoviesModel.toUpcomingMoviesEntity());
    } on ServerException {
      return Left(ServerException());
    } on BadRequestException {
      return Left(BadRequestException());
    } on ForbiddenException {
      return Left(ForbiddenException());
    } on UnauthorizedException {
      return Left(UnauthorizedException());
    } on CustomException {
      return Left((CustomException()));
    } on DowntimeException {
      return Left(DowntimeException());
    } catch (e) {
      return Left(UnknownException());
    }
  }

  @override
  Future<Either<Exception, MovieDetailEntity>> getMovieDetail(
      int movieId) async {
    try {
      GetMovieDetailModel getMovieDetailModel =
          await movieRemoteDataSource.getMovieDetail(movieId);
      return Right(getMovieDetailModel.toMovieDetailEntity());
    } on ServerException {
      return Left(ServerException());
    } on BadRequestException {
      return Left(BadRequestException());
    } on ForbiddenException {
      return Left(ForbiddenException());
    } on UnauthorizedException {
      return Left(UnauthorizedException());
    } on CustomException {
      return Left((CustomException()));
    } on DowntimeException {
      return Left(DowntimeException());
    } catch (e) {
      return Left(UnknownException());
    }
  }

  @override
  Future<Either<Exception, MovieTrailerEntity>> getMovieTrailerUrl(
      int movieId) async {
    try {
      GetMovieTrailerModel getMovieTrailerModel =
          await movieRemoteDataSource.getMovieTrailer(movieId);
      return Right(getMovieTrailerModel.toMovieTrailerEntity());
    } on ServerException {
      return Left(ServerException());
    } on BadRequestException {
      return Left(BadRequestException());
    } on ForbiddenException {
      return Left(ForbiddenException());
    } on UnauthorizedException {
      return Left(UnauthorizedException());
    } on CustomException {
      return Left((CustomException()));
    } on DowntimeException {
      return Left(DowntimeException());
    } catch (e) {
      return Left(UnknownException());
    }
  }

  @override
  Future<Either<Exception, List<MovieCastEntity>>> getMovieCast(
      int movieId) async {
    try {
      GetMovieCastModel getMovieCastModel =
          await movieRemoteDataSource.getMovieCast(movieId);
      return Right(getMovieCastModel.toMovieCastEntity());
    } on ServerException {
      return Left(ServerException());
    } on BadRequestException {
      return Left(BadRequestException());
    } on ForbiddenException {
      return Left(ForbiddenException());
    } on UnauthorizedException {
      return Left(UnauthorizedException());
    } on CustomException {
      return Left((CustomException()));
    } on DowntimeException {
      return Left(DowntimeException());
    } catch (e) {
      return Left(UnknownException());
    }
  }
}
