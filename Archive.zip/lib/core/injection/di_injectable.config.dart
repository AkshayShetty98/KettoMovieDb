// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// InjectableConfigGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:get_it/get_it.dart' as _i1;
import 'package:injectable/injectable.dart' as _i2;
import 'package:kettomoviedb/features/movies/data/datasources/movie_remote_data_source.dart'
    as _i4;
import 'package:kettomoviedb/features/movies/data/repositories/movie_repository_impl.dart'
    as _i6;
import 'package:kettomoviedb/features/movies/domain/repositories/movie_repository.dart'
    as _i5;
import 'package:kettomoviedb/features/movies/domain/usecases/get_movie_cast.dart'
    as _i7;
import 'package:kettomoviedb/features/movies/domain/usecases/get_movie_detail.dart'
    as _i8;
import 'package:kettomoviedb/features/movies/domain/usecases/get_movie_trailer.dart'
    as _i9;
import 'package:kettomoviedb/features/movies/domain/usecases/get_popular_movies.dart'
    as _i10;
import 'package:kettomoviedb/features/movies/domain/usecases/get_toprated_movies.dart'
    as _i11;
import 'package:kettomoviedb/features/movies/domain/usecases/get_upcoming_movies.dart'
    as _i12;
import 'package:kettomoviedb/features/movies/presentation/bloc/movies_bloc.dart'
    as _i13;
import 'package:kettomoviedb/utils/helpers/http_client.dart' as _i3;

extension GetItInjectableX on _i1.GetIt {
// initializes the registration of main-scope dependencies inside of GetIt
  _i1.GetIt init({
    String? environment,
    _i2.EnvironmentFilter? environmentFilter,
  }) {
    final gh = _i2.GetItHelper(
      this,
      environment,
      environmentFilter,
    );
    gh.factory<_i3.HttpClient>(() => _i3.HttpClient());
    gh.lazySingleton<_i4.MovieRemoteDataSource>(
        () => _i4.MovieRemoteDataSourceImpl(gh<_i3.HttpClient>()));
    gh.lazySingleton<_i5.MovieRepository>(
        () => _i6.MovieRepositoryImpl(gh<_i4.MovieRemoteDataSource>()));
    gh.lazySingleton<_i7.GetMovieCast>(
        () => _i7.GetMovieCast(movieRepository: gh<_i5.MovieRepository>()));
    gh.lazySingleton<_i8.GetMovieDetail>(
        () => _i8.GetMovieDetail(movieRepository: gh<_i5.MovieRepository>()));
    gh.lazySingleton<_i9.GetMovieTrailer>(
        () => _i9.GetMovieTrailer(movieRepository: gh<_i5.MovieRepository>()));
    gh.lazySingleton<_i10.GetPopularMovies>(() =>
        _i10.GetPopularMovies(movieRepository: gh<_i5.MovieRepository>()));
    gh.lazySingleton<_i11.GetTopratedMovies>(() =>
        _i11.GetTopratedMovies(movieRepository: gh<_i5.MovieRepository>()));
    gh.lazySingleton<_i12.GetUpcomingdMovies>(() =>
        _i12.GetUpcomingdMovies(movieRepository: gh<_i5.MovieRepository>()));
    gh.factory<_i13.MoviesBloc>(() => _i13.MoviesBloc(
          getPopularMovies: gh<_i10.GetPopularMovies>(),
          getTopratedMovies: gh<_i11.GetTopratedMovies>(),
          getUpcomingdMovies: gh<_i12.GetUpcomingdMovies>(),
          getMovieDetail: gh<_i8.GetMovieDetail>(),
          getMovieTrailer: gh<_i9.GetMovieTrailer>(),
          getMovieCast: gh<_i7.GetMovieCast>(),
        ));
    return this;
  }
}
