import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_intro_entity.dart';
import 'package:kettomoviedb/features/movies/presentation/pages/movie_detail_page.dart';
import 'package:kettomoviedb/utils/access-config/app_urls.dart';
import 'package:kettomoviedb/utils/styling/textstyles.dart';

class MoviesSectionWidget extends StatefulWidget {
  final String sectionType;
  final PagingController<int, MovieIntroEntity> pagingController;
  const MoviesSectionWidget(
      {super.key, required this.sectionType, required this.pagingController});

  @override
  State<MoviesSectionWidget> createState() => _MoviesSectionWidgetState();
}

class _MoviesSectionWidgetState extends State<MoviesSectionWidget> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '${widget.sectionType} Movies',
          style: headlineMediumStyle(context),
        ),
        const SizedBox(
          height: 10,
        ),
        SizedBox(
          height: 200,
          child: PagedListView<int, MovieIntroEntity>(
            scrollDirection: Axis.horizontal,
            pagingController: widget.pagingController,
            builderDelegate: PagedChildBuilderDelegate<MovieIntroEntity>(
              itemBuilder: (context, item, index) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 0.0),
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => MovieDetailPage(
                                  movieId: item.movieId,
                                )),
                      );
                    },
                    child: Container(
                      width: 150.0,
                      margin: const EdgeInsets.only(right: 10),
                      decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        borderRadius: BorderRadius.circular(10),
                        image: DecorationImage(
                          fit: BoxFit.fill,
                          image: CachedNetworkImageProvider(
                              imgBaseUrl + item.moviePosterUrl),
                        ),
                      ),
                    ),
                  )),
              firstPageErrorIndicatorBuilder: (context) => const Center(
                child: Text('Error'),
              ),
              firstPageProgressIndicatorBuilder: (context) =>
                  const CircularProgressIndicator(),
              noItemsFoundIndicatorBuilder: (context) {
                return Center(
                  child: Container(),
                );
              },
              noMoreItemsIndicatorBuilder: (context) {
                return Text(
                  '****No more movies****',
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall!
                      .copyWith(color: Colors.black),
                  textAlign: TextAlign.center,
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}
