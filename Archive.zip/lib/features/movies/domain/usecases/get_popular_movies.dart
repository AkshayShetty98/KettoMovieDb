// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';

import 'package:kettomoviedb/core/usecase/usecase.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_intro_entity.dart';
import 'package:kettomoviedb/features/movies/domain/repositories/movie_repository.dart';

@lazySingleton
class GetPopularMovies
    extends UseCase<AllMoviesIntroEntity, GetPopularMoviesParams> {
  final MovieRepository movieRepository;

  GetPopularMovies({
    required this.movieRepository,
  });

  @override
  Future<Either<Exception, AllMoviesIntroEntity>> call(
      GetPopularMoviesParams params) async {
    return await movieRepository.getPopularMovies(params.page);
  }
}

class GetPopularMoviesParams extends Equatable {
  final int page;

  const GetPopularMoviesParams({required this.page});

  @override
  List<Object> get props => [page];
}
