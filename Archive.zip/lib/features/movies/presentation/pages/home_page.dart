import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:kettomoviedb/core/injection/di_injectable.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_intro_entity.dart';
import 'package:kettomoviedb/features/movies/presentation/bloc/movies_bloc.dart';
import 'package:kettomoviedb/features/movies/presentation/widgets/movies_section_widget.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late final MoviesBloc _moviesBloc;
  int pageIndex = 1; //
  int pageIndextTopRated = 1;
  int pageIndexUpcoming = 1;
  late final PagingController<int, MovieIntroEntity> _popMoviesController;
  late final PagingController<int, MovieIntroEntity> _topMoviesController;
  late final PagingController<int, MovieIntroEntity> _upcomingMoviesController;

  @override
  void initState() {
    _moviesBloc = sl<MoviesBloc>();
    _moviesBloc.add(GetPopularMoviesEvent(pageIndex));
    _moviesBloc.add(GetTopratedMoviesEvent(pageIndextTopRated));
    _moviesBloc.add(GetUpcomingMoviesEvent(pageIndexUpcoming));
    _popMoviesController = PagingController(firstPageKey: pageIndex);
    _popMoviesController.addPageRequestListener((pageKey) {
      _moviesBloc.add(GetPopularMoviesEvent(pageKey));
    });
    _topMoviesController = PagingController(firstPageKey: pageIndextTopRated);
    _topMoviesController.addPageRequestListener((pageKey) {
      _moviesBloc.add(GetTopratedMoviesEvent(pageKey));
    });
    _upcomingMoviesController =
        PagingController(firstPageKey: pageIndexUpcoming);
    _upcomingMoviesController.addPageRequestListener((pageKey) {
      _moviesBloc.add(GetUpcomingMoviesEvent(pageKey));
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: BlocProvider(
          create: (context) => _moviesBloc,
          child: BlocListener<MoviesBloc, MoviesState>(
            listener: (context, state) {
              if (state is GetPopularMoviesSuccess) {
                bool lastPage =
                    pageIndex >= state.allMoviesIntroEntity.totalPages;

                final next = pageIndex + 1;
                pageIndex = pageIndex + 1;
                if (lastPage) {
                  _popMoviesController
                      .appendLastPage(state.allMoviesIntroEntity.allMovies);
                } else {
                  _popMoviesController.appendPage(
                      state.allMoviesIntroEntity.allMovies, next);
                }
              } else if (state is GetTopratedMoviesSuccess) {
                bool lastPage =
                    pageIndex >= state.allMoviesIntroEntity.totalPages;

                final next = pageIndex + 1;
                pageIndex = pageIndex + 1;
                if (lastPage) {
                  _topMoviesController
                      .appendLastPage(state.allMoviesIntroEntity.allMovies);
                } else {
                  _topMoviesController.appendPage(
                      state.allMoviesIntroEntity.allMovies, next);
                }
              } else if (state is GetUpcomingMoviesSuccess) {
                bool lastPage =
                    pageIndex >= state.allMoviesIntroEntity.totalPages;

                final next = pageIndex + 1;
                pageIndex = pageIndex + 1;
                if (lastPage) {
                  _upcomingMoviesController
                      .appendLastPage(state.allMoviesIntroEntity.allMovies);
                } else {
                  _upcomingMoviesController.appendPage(
                      state.allMoviesIntroEntity.allMovies, next);
                }
              }
            },
            child: SingleChildScrollView(
              child: Container(
                padding: const EdgeInsets.all(10),
                child: Column(
                  children: [
                    BlocBuilder<MoviesBloc, MoviesState>(
                      buildWhen: (previous, current) =>
                          current is GetPopularMoviesSuccess,
                      builder: (context, state) {
                        if (state is GetPopularMoviesSuccess) {
                          return MoviesSectionWidget(
                              sectionType: 'Popular',
                              pagingController: _popMoviesController);
                        } else {
                          return Container();
                        }
                      },
                    ),
                    const SizedBox(height: 30),
                    BlocBuilder<MoviesBloc, MoviesState>(
                      buildWhen: (previous, current) =>
                          current is GetTopratedMoviesSuccess,
                      builder: (context, state) {
                        if (state is GetTopratedMoviesSuccess) {
                          return MoviesSectionWidget(
                              sectionType: 'Top Rated',
                              pagingController: _topMoviesController);
                        } else {
                          return Container();
                        }
                      },
                    ),
                    const SizedBox(height: 30),
                    BlocBuilder<MoviesBloc, MoviesState>(
                      buildWhen: (previous, current) =>
                          current is GetUpcomingMoviesSuccess,
                      builder: (context, state) {
                        if (state is GetUpcomingMoviesSuccess) {
                          return MoviesSectionWidget(
                              sectionType: 'Upcoming',
                              pagingController: _upcomingMoviesController);
                        } else {
                          return Container();
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
