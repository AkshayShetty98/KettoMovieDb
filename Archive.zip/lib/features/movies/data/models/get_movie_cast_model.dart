// To parse this JSON data, do
//
//     final getMovieCastModel = getMovieCastModelFromJson(jsonString);

import 'dart:convert';

import 'package:kettomoviedb/features/movies/domain/entities/movie_cast_entity.dart';

GetMovieCastModel getMovieCastModelFromJson(String str) =>
    GetMovieCastModel.fromJson(json.decode(str));

String getMovieCastModelToJson(GetMovieCastModel data) =>
    json.encode(data.toJson());

class GetMovieCastModel {
  int id;
  List<Cast> cast;
  List<Cast> crew;

  GetMovieCastModel({
    required this.id,
    required this.cast,
    required this.crew,
  });

  factory GetMovieCastModel.fromJson(Map<String, dynamic> json) =>
      GetMovieCastModel(
        id: json["id"],
        cast: List<Cast>.from(json["cast"].map((x) => Cast.fromJson(x))),
        crew: List<Cast>.from(json["crew"].map((x) => Cast.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "cast": List<dynamic>.from(cast.map((x) => x.toJson())),
        "crew": List<dynamic>.from(crew.map((x) => x.toJson())),
      };
  List<MovieCastEntity> toMovieCastEntity() {
    List<MovieCastEntity> movieCast = [];
    for (var element in cast) {
      if (element.gender == 1 &&
          element.knownForDepartment.toUpperCase() == 'ACTING') {
        movieCast.add(element.toMovieCastEntity());
      }
    }
    return movieCast;
  }
}

class Cast {
  bool adult;
  int gender;
  int id;
  String knownForDepartment;
  String name;
  String originalName;
  double popularity;
  String? profilePath;
  int? castId;
  String? character;
  String creditId;
  int? order;
  String? department;
  String? job;

  Cast({
    required this.adult,
    required this.gender,
    required this.id,
    required this.knownForDepartment,
    required this.name,
    required this.originalName,
    required this.popularity,
    required this.profilePath,
    this.castId,
    this.character,
    required this.creditId,
    this.order,
    this.department,
    this.job,
  });

  factory Cast.fromJson(Map<String, dynamic> json) => Cast(
        adult: json["adult"],
        gender: json["gender"],
        id: json["id"],
        knownForDepartment: json["known_for_department"],
        name: json["name"],
        originalName: json["original_name"],
        popularity: json["popularity"]?.toDouble(),
        profilePath: json["profile_path"],
        castId: json["cast_id"],
        character: json["character"],
        creditId: json["credit_id"],
        order: json["order"],
        department: json["department"],
        job: json["job"],
      );

  Map<String, dynamic> toJson() => {
        "adult": adult,
        "gender": gender,
        "id": id,
        "known_for_department": knownForDepartment,
        "name": name,
        "original_name": originalName,
        "popularity": popularity,
        "profile_path": profilePath,
        "cast_id": castId,
        "character": character,
        "credit_id": creditId,
        "order": order,
        "department": department,
        "job": job,
      };
  MovieCastEntity toMovieCastEntity() =>
      MovieCastEntity(castName: name, castPicUrl: profilePath ?? '');
}
