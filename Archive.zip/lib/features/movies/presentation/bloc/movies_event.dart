part of 'movies_bloc.dart';

abstract class MoviesEvent extends Equatable {
  const MoviesEvent();

  @override
  List<Object> get props => [];
}

class GetPopularMoviesEvent extends MoviesEvent {
  final int page;

  const GetPopularMoviesEvent(this.page);
  @override
  List<Object> get props => [page];
}

class GetTopratedMoviesEvent extends MoviesEvent {
  final int page;

  const GetTopratedMoviesEvent(this.page);
  @override
  List<Object> get props => [page];
}

class GetUpcomingMoviesEvent extends MoviesEvent {
  final int page;

  const GetUpcomingMoviesEvent(this.page);
  @override
  List<Object> get props => [page];
}

class GetMovieDetailEvent extends MoviesEvent {
  final int movieId;

  const GetMovieDetailEvent(this.movieId);
  @override
  List<Object> get props => [movieId];
}

class GetMovieTrailerEvent extends MoviesEvent {
  final int movieId;

  const GetMovieTrailerEvent(this.movieId);
  @override
  List<Object> get props => [movieId];
}

class GetMovieCastEvent extends MoviesEvent {
  final int movieId;

  const GetMovieCastEvent(this.movieId);
  @override
  List<Object> get props => [movieId];
}
