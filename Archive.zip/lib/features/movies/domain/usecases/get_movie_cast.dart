import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';
import 'package:kettomoviedb/core/usecase/usecase.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_cast_entity.dart';
import 'package:kettomoviedb/features/movies/domain/repositories/movie_repository.dart';

@lazySingleton
class GetMovieCast extends UseCase<List<MovieCastEntity>, GetMovieCastParams> {
  final MovieRepository movieRepository;

  GetMovieCast({
    required this.movieRepository,
  });

  @override
  Future<Either<Exception, List<MovieCastEntity>>> call(
      GetMovieCastParams params) async {
    return await movieRepository.getMovieCast(params.movieId);
  }
}

class GetMovieCastParams extends Equatable {
  final int movieId;

  const GetMovieCastParams({required this.movieId});

  @override
  List<Object> get props => [movieId];
}
