// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';

import 'package:kettomoviedb/core/usecase/usecase.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_intro_entity.dart';
import 'package:kettomoviedb/features/movies/domain/repositories/movie_repository.dart';

@lazySingleton
class GetTopratedMovies
    extends UseCase<AllMoviesIntroEntity, GetTopratedMoviesParams> {
  final MovieRepository movieRepository;

  GetTopratedMovies({
    required this.movieRepository,
  });

  @override
  Future<Either<Exception, AllMoviesIntroEntity>> call(
      GetTopratedMoviesParams params) async {
    return await movieRepository.getTopRatedMovies(params.page);
  }
}

class GetTopratedMoviesParams extends Equatable {
  final int page;

  const GetTopratedMoviesParams({required this.page});

  @override
  List<Object> get props => [page];
}
