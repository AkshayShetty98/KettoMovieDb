class ServerException implements Exception {}

class CacheException implements Exception {}

class InternetException implements Exception {}

class BadRequestException implements Exception {}

class UnauthorizedException implements Exception {}

class ForbiddenException implements Exception {}

class InvalidOtpException implements Exception {}

class ExpiredOtpException implements Exception {}

class CustomException implements Exception {}

class UnknownException implements Exception {}

class DowntimeException implements Exception {}
