import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_cast_entity.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_detail_entity.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_intro_entity.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_trailer_entity.dart';
import 'package:kettomoviedb/features/movies/domain/usecases/get_movie_cast.dart';
import 'package:kettomoviedb/features/movies/domain/usecases/get_movie_detail.dart';
import 'package:kettomoviedb/features/movies/domain/usecases/get_movie_trailer.dart';
import 'package:kettomoviedb/features/movies/domain/usecases/get_popular_movies.dart';
import 'package:kettomoviedb/features/movies/domain/usecases/get_toprated_movies.dart';
import 'package:kettomoviedb/features/movies/domain/usecases/get_upcoming_movies.dart';

part 'movies_event.dart';
part 'movies_state.dart';

@injectable
class MoviesBloc extends Bloc<MoviesEvent, MoviesState> {
  final GetPopularMovies getPopularMovies;
  final GetTopratedMovies getTopratedMovies;
  final GetUpcomingdMovies getUpcomingdMovies;
  final GetMovieDetail getMovieDetail;
  final GetMovieTrailer getMovieTrailer;
  final GetMovieCast getMovieCast;
  MoviesBloc(
      {required this.getPopularMovies,
      required this.getTopratedMovies,
      required this.getUpcomingdMovies,
      required this.getMovieDetail,
      required this.getMovieTrailer,
      required this.getMovieCast})
      : super(MoviesInitial()) {
    on<MoviesEvent>((event, emit) {});
    on<GetPopularMoviesEvent>(
      (event, emit) async {
        emit(GetPopularMoviesLoading());
        final data = await getPopularMovies
            .call(GetPopularMoviesParams(page: event.page));

        data.fold((l) {
          emit(GetPopularMoviesFailure());
        }, (r) {
          emit(GetPopularMoviesSuccess(allMoviesIntroEntity: r));
        });
      },
    );
    on<GetTopratedMoviesEvent>(
      (event, emit) async {
        emit(GetTopratedMoviesLoading());
        final data = await getTopratedMovies
            .call(GetTopratedMoviesParams(page: event.page));

        data.fold((l) {
          emit(GetTopratedMoviesFailure());
        }, (r) {
          emit(GetTopratedMoviesSuccess(allMoviesIntroEntity: r));
        });
      },
    );
    on<GetUpcomingMoviesEvent>(
      (event, emit) async {
        emit(GetUpcomingMoviesLoading());
        final data = await getUpcomingdMovies
            .call(GetUpcomingMoviesParams(page: event.page));

        data.fold((l) {
          emit(GetUpcomingMoviesFailure());
        }, (r) {
          emit(GetUpcomingMoviesSuccess(allMoviesIntroEntity: r));
        });
      },
    );
    on<GetMovieDetailEvent>(
      (event, emit) async {
        emit(GetMovieDetailLoading());
        final data = await getMovieDetail
            .call(GetMovieDetailParams(movieId: event.movieId));

        data.fold((l) {
          emit(GetMovieDetailFailure());
        }, (r) {
          emit(GetMovieDetailSuccess(movieDetailEntity: r));
        });
      },
    );
    on<GetMovieTrailerEvent>(
      (event, emit) async {
        emit(GetMovieTrailerLoading());
        final data = await getMovieTrailer
            .call(GetMovieTrailerParams(movieId: event.movieId));

        data.fold((l) {
          emit(GetMovieTrailerFailure());
        }, (r) {
          emit(GetMovieTrailerSuccess(movieTrailerEntity: r));
        });
      },
    );
    on<GetMovieCastEvent>(
      (event, emit) async {
        emit(GetMovieCastLoading());
        final data =
            await getMovieCast.call(GetMovieCastParams(movieId: event.movieId));

        data.fold((l) {
          emit(GetMovieCastFailure());
        }, (r) {
          emit(GetMovieCastSuccess(movieCastEntity: r));
        });
      },
    );
  }
}
