// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:equatable/equatable.dart';

class MovieDetailEntity extends Equatable {
  final int movieId;
  final String movieName;
  final String movieOverview;
  final num score;
  final DateTime releaseDate;
  final int runTime;
  final String backdropImageUrl;
  const MovieDetailEntity(
      {required this.movieId,
      required this.movieName,
      required this.movieOverview,
      required this.score,
      required this.releaseDate,
      required this.runTime,
      required this.backdropImageUrl});

  @override
  List<Object> get props {
    return [
      movieId,
      movieName,
      movieOverview,
      score,
      releaseDate,
      runTime,
      backdropImageUrl
    ];
  }
}
