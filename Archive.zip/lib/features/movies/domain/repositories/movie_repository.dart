import 'package:dartz/dartz.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_cast_entity.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_detail_entity.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_intro_entity.dart';
import 'package:kettomoviedb/features/movies/domain/entities/movie_trailer_entity.dart';

abstract class MovieRepository {
  Future<Either<Exception, AllMoviesIntroEntity>> getPopularMovies(int page);
  Future<Either<Exception, AllMoviesIntroEntity>> getTopRatedMovies(int page);
  Future<Either<Exception, AllMoviesIntroEntity>> getUpcomingMovies(int page);
  Future<Either<Exception, MovieDetailEntity>> getMovieDetail(int movieId);
  Future<Either<Exception, MovieTrailerEntity>> getMovieTrailerUrl(int movieId);
  Future<Either<Exception, List<MovieCastEntity>>> getMovieCast(int movieId);
}
