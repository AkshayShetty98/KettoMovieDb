import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:kettomoviedb/core/injection/di_injectable.dart';
import 'package:kettomoviedb/features/movies/presentation/bloc/movies_bloc.dart';
import 'package:kettomoviedb/utils/access-config/app_urls.dart';
import 'package:kettomoviedb/utils/styling/textstyles.dart';
import 'package:url_launcher/url_launcher.dart';

class MovieDetailPage extends StatefulWidget {
  final int movieId;
  const MovieDetailPage({super.key, required this.movieId});

  @override
  State<MovieDetailPage> createState() => _MovieDetailPageState();
}

class _MovieDetailPageState extends State<MovieDetailPage> {
  late final MoviesBloc _moviesBloc;
  String movieYoutubeUrl = '';

  @override
  void initState() {
    _moviesBloc = sl<MoviesBloc>();
    _moviesBloc.add(GetMovieDetailEvent(widget.movieId));

    _moviesBloc.add(GetMovieCastEvent(widget.movieId));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocProvider(
        create: (context) => _moviesBloc,
        child: BlocListener<MoviesBloc, MoviesState>(
          listenWhen: (previous, current) => current is GetMovieTrailerSuccess,
          listener: (context, state) async {
            if (state is GetMovieTrailerSuccess) {
              movieYoutubeUrl = state.movieTrailerEntity.youtubeUrlKey;
              final url = 'https://www.youtube.com/watch?v=$movieYoutubeUrl';
              if (await canLaunchUrl(Uri.parse(url))) {
                await launchUrl(Uri.parse(url));
              } else {
                throw 'Could not launch $url';
              }
            }
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              BlocBuilder<MoviesBloc, MoviesState>(
                buildWhen: (previous, current) =>
                    current is GetMovieDetailLoading ||
                    current is GetMovieDetailSuccess,
                builder: (context, state) {
                  if (state is GetMovieDetailLoading) {
                    return Container();
                  } else if (state is GetMovieDetailSuccess) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: 320,
                          child: Stack(
                            // alignment: Alignment.topCenter,
                            children: [
                              CachedNetworkImage(
                                imageUrl:
                                    '$imgBaseUrl${state.movieDetailEntity.backdropImageUrl}',
                                width: double.maxFinite,
                                fit: BoxFit.cover,
                                height: 300,
                              ),
                              Positioned(
                                bottom: 60,
                                left: 30,
                                child: Container(
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.6),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Row(
                                    children: [
                                      const Icon(
                                        Icons.star,
                                        size: 18,
                                        color:
                                            Color.fromARGB(255, 253, 176, 60),
                                      ),
                                      const SizedBox(
                                        width: 5,
                                      ),
                                      Text(
                                          state.movieDetailEntity.score
                                              .toString(),
                                          style: const TextStyle(
                                              color: Colors.white))
                                    ],
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.bottomCenter,
                                child: ElevatedButton(
                                    onPressed: () {
                                      _moviesBloc.add(
                                          GetMovieTrailerEvent(widget.movieId));
                                    },
                                    child: const Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(Icons.movie_creation),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Text('Watch Trailer')
                                      ],
                                    )),
                              )
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                state.movieDetailEntity.movieName,
                                style: headlineMediumStyle(context)
                                    .copyWith(color: Colors.red),
                              ),
                              Text(
                                state.movieDetailEntity.movieOverview,
                                style: bodySmallStyle(context),
                              ),
                            ],
                          ),
                        )
                      ],
                    );
                  } else {
                    return Container();
                  }
                },
              ),
              const SizedBox(
                height: 30,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Text(
                  'Female Cast',
                  style: bodyMediumStyle(context),
                ),
              ),
              const SizedBox(
                height: 8,
              ),
              BlocBuilder<MoviesBloc, MoviesState>(
                buildWhen: (previous, current) =>
                    current is GetMovieCastLoading ||
                    current is GetMovieCastSuccess,
                builder: (context, state) {
                  if (state is GetMovieCastLoading) {
                    return Container();
                  } else if (state is GetMovieCastSuccess) {
                    return Container(
                      height: 150,
                      padding: const EdgeInsets.all(10),
                      child: ListView.builder(
                        itemCount: state.movieCastEntity.length,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return Container(
                            margin: const EdgeInsets.only(right: 8),
                            child: Column(
                              children: [
                                CircleAvatar(
                                  radius: 45,
                                  backgroundImage: CachedNetworkImageProvider(
                                    imgBaseUrl +
                                        state.movieCastEntity[index].castPicUrl,
                                  ),
                                ),
                                const SizedBox(
                                  height: 8,
                                ),
                                Text(
                                  state.movieCastEntity[index].castName,
                                  style: bodySmallStyle(context),
                                )
                              ],
                            ),
                          );
                        },
                      ),
                    );
                  } else {
                    return Container();
                  }
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
